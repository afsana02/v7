<?php
$conn=new mysqli("localhost","root","","conv");

if(isset($_POST['submit'])&&isset($_POST['phone']))
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$Websitetype=$_POST['Websitetype'];
	$WebpageRequired=$_POST['WebpageRequired'];
	$Contentwriting=$_POST['Contentwriting'];
	$WebsiteRequiredin=$_POST['WebsiteRequiredin'];
	$HostingServices=$_POST['HostingServices'];
	$DomainName=$_POST['DomainName'];


	$sql="insert into tbl_conv values('$name','$email','$phone','$Websitetype','$WebpageRequired','$Contentwriting','$WebsiteRequiredin','$HostingServices','$DomainName')";
	if(mysqli_query($conn,$sql)==True)
	{
		
		echo "<script>
		 alert('Thank You! Your Data has been submitted successfully!. We will catch you soon.');
		 window.location.href='index.php' ;
		 </script>";

	}
}
else echo "error_log";
mysqli_close($conn);

?>

